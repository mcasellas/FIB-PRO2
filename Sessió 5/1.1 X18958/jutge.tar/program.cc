#include "PilaIOParInt.hh"
#include "ParInt.hh"

int trobar_element(stack<ParInt> pila, int n) {
    while (not pila.empty()) {
        if (pila.top().primer() == n) {
            return pila.top().segon();
        }
        pila.pop();
    }
    return -1;
}

int main() {
    stack<ParInt> pila;

    llegirPilaParInt(pila);
    int n;
    cin >> n;

    int element = trobar_element(pila, n);

    escriurePilaParInt(pila);

    if (element != -1) cout << element << endl;

    else cout << "No trobat" << endl;
}
