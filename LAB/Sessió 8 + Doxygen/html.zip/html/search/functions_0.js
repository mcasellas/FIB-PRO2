var searchData=
[
  ['afegir_5findividu',['afegir_individu',['../class_poblacio.html#ae56d498cf63b075d775968f0f880e9f1',1,'Poblacio']]]
];
