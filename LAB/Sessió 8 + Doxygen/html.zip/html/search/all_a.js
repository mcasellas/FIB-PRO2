var searchData=
[
  ['reproduir',['reproduir',['../class_individu.html#a38c1693172190ae30f0577a3d5459b94',1,'Individu::reproduir()'],['../class_poblacio.html#a9e31f2e6394618bc130280322cb24fbf',1,'Poblacio::reproduir()']]]
];
