var indexSectionsWithContent =
{
  0: "abcdeilmnprs",
  1: "eip",
  2: "eip",
  3: "abceilmpr",
  4: "aclmnps",
  5: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Pàgines"
};

