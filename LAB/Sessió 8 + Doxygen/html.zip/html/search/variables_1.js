var searchData=
[
  ['c1',['c1',['../class_parell__cromosomes.html#ab7f48c884531da8e1fe3a08d80235c9a',1,'Parell_cromosomes']]],
  ['c2',['c2',['../class_parell__cromosomes.html#a6e3169a9ca8b8d508ce1c0143a5b4a82',1,'Parell_cromosomes']]]
];
