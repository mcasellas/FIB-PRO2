var searchData=
[
  ['pare',['pare',['../class_individu.html#acd37349b1c7db6e07cd88eade7c622c0',1,'Individu']]],
  ['poble',['poble',['../class_poblacio.html#adc5549ea0f51e16440bc4cf0928b0d50',1,'Poblacio']]]
];
