var searchData=
[
  ['parell_5fcromosomes',['Parell_cromosomes',['../class_parell__cromosomes.html',1,'']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'']]]
];
