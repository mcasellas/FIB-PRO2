var searchData=
[
  ['completar_5farbre',['completar_arbre',['../class_poblacio.html#abe25acd8c2ce02a747ab79f26cc74f11',1,'Poblacio']]],
  ['comprovar_5freproduccio',['comprovar_reproduccio',['../class_poblacio.html#a1f54c4af151e3e8433f36342db0f984d',1,'Poblacio']]],
  ['consultar_5fcromosoma',['consultar_cromosoma',['../class_parell__cromosomes.html#ac031fd24ba85d2bc3384afaf6c81ac23',1,'Parell_cromosomes']]],
  ['consultar_5findividu',['consultar_individu',['../class_poblacio.html#a0574c7b81e2b8329fb2ffcd0b4365a98',1,'Poblacio']]],
  ['consultar_5fln',['consultar_ln',['../class_especie.html#aaa23d14e7e07335ff033d31e89e359ec',1,'Especie']]],
  ['consultar_5flx',['consultar_lx',['../class_especie.html#a35b595c9f7dcf3e23b9c85278f72322e',1,'Especie']]],
  ['consultar_5fly',['consultar_ly',['../class_especie.html#afba7e27b8516600f74ff683b90e9fa40',1,'Especie']]],
  ['consultar_5fmare',['consultar_mare',['../class_individu.html#a46a9823e9287c90d0ad58d494317ea65',1,'Individu']]],
  ['consultar_5fn',['consultar_n',['../class_especie.html#ab8a394dfdea959e383645ae90d0086ca',1,'Especie']]],
  ['consultar_5fpare',['consultar_pare',['../class_individu.html#a0807da1b89bb753f7bb92e1c39cefa44',1,'Individu']]],
  ['consultar_5fparell_5fcromosomes',['consultar_parell_cromosomes',['../class_individu.html#a1493ec6bfadc929b425bebb0c1a3a9c9',1,'Individu']]],
  ['consultar_5fsexe',['consultar_sexe',['../class_individu.html#a06f4e5e857afbbcf9599d04c54a4f3a1',1,'Individu']]],
  ['creuament',['creuament',['../class_parell__cromosomes.html#a4be1f5db491e742fa2ced6a22442c0a2',1,'Parell_cromosomes']]]
];
