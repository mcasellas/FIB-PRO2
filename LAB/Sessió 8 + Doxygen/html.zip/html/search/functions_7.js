var searchData=
[
  ['parell_5fcromosomes',['Parell_cromosomes',['../class_parell__cromosomes.html#a7985c1aa62522044b5e713e065d91463',1,'Parell_cromosomes']]],
  ['poblacio',['Poblacio',['../class_poblacio.html#ac0183157c2cdadc3ef95d11b6614700a',1,'Poblacio']]]
];
