var searchData=
[
  ['l',['l',['../class_especie.html#ae32ed22b56d80f11c181911c67fa0e95',1,'Especie']]],
  ['llegir',['llegir',['../class_poblacio.html#a29df411fde89d37a05fb705e1cc3dd8b',1,'Poblacio']]],
  ['llegir_5farbre_5fparcial',['llegir_arbre_parcial',['../class_poblacio.html#a0b60d947870b310929e4fc451b13ec01',1,'Poblacio']]],
  ['llegir_5fcromosomes_5fno_5fsexuals',['llegir_cromosomes_no_sexuals',['../class_parell__cromosomes.html#a5d96548d03bc22d40125a76c5654b3cd',1,'Parell_cromosomes']]],
  ['llegir_5fcromosomes_5fsexuals',['llegir_cromosomes_sexuals',['../class_parell__cromosomes.html#a63a4bff5f37c05ff7b6834ff48b4ceba',1,'Parell_cromosomes']]],
  ['llegir_5findividu',['llegir_individu',['../class_individu.html#ad0f73f2395d08a8d9de8604c2bede4d6',1,'Individu']]],
  ['llegir_5finicials',['llegir_inicials',['../class_poblacio.html#a8757ef86688a1e2c25d9264aea934a28',1,'Poblacio']]],
  ['lx',['lx',['../class_especie.html#ade4c4e0e145af39d14078b08b3b03df8',1,'Especie']]],
  ['ly',['ly',['../class_especie.html#a5d8a4e5dced433508eb01bd748c6b562',1,'Especie']]]
];
