var searchData=
[
  ['buscar_5farbre',['buscar_arbre',['../class_poblacio.html#ad35ab2cc93d5d79061e4bb4829ace045',1,'Poblacio']]],
  ['buscar_5fascendent',['buscar_ascendent',['../class_poblacio.html#aec49e868f8a0373f575ff86579e4f9ad',1,'Poblacio']]]
];
