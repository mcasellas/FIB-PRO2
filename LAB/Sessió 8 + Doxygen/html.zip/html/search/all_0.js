var searchData=
[
  ['adn',['adn',['../class_individu.html#a9e3ff2f5573b349ddb98dff46b11e143',1,'Individu']]],
  ['afegir_5findividu',['afegir_individu',['../class_poblacio.html#ae56d498cf63b075d775968f0f880e9f1',1,'Poblacio']]]
];
