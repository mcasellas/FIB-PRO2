var searchData=
[
  ['pare',['pare',['../class_individu.html#acd37349b1c7db6e07cd88eade7c622c0',1,'Individu']]],
  ['parell_5fcromosomes',['Parell_cromosomes',['../class_parell__cromosomes.html',1,'Parell_cromosomes'],['../class_parell__cromosomes.html#a7985c1aa62522044b5e713e065d91463',1,'Parell_cromosomes::Parell_cromosomes()']]],
  ['parellcromosomes_2ecc',['Parellcromosomes.cc',['../_parellcromosomes_8cc.html',1,'']]],
  ['parellcromosomes_2ehh',['Parellcromosomes.hh',['../_parellcromosomes_8hh.html',1,'']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'Poblacio'],['../class_poblacio.html#ac0183157c2cdadc3ef95d11b6614700a',1,'Poblacio::Poblacio()']]],
  ['poblacio_2ecc',['Poblacio.cc',['../_poblacio_8cc.html',1,'']]],
  ['poblacio_2ehh',['Poblacio.hh',['../_poblacio_8hh.html',1,'']]],
  ['poble',['poble',['../class_poblacio.html#adc5549ea0f51e16440bc4cf0928b0d50',1,'Poblacio']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]]
];
