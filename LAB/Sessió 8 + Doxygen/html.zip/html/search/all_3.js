var searchData=
[
  ['disseny_20modular_3a_20experiments_20genètics_20en_20un_20laboratori_2e',['Disseny modular: Experiments genètics en un laboratori.',['../index.html',1,'']]]
];
